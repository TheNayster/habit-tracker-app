
import React, { useState } from "react"
import { View, Text, TouchableOpacity, StyleSheet } from "react-native"
import { Calendar, Agenda } from "react-native-calendars"
import { Screen } from "app/components"
import { colors, spacing } from "app/theme"

export function CalendarScreen() {
  const [view, setView] = useState<"day" | "week" | "month">("month")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])

  const renderToggle = () => (
    <View style={styles.toggleContainer}>
      {["day", "week", "month"].map((option) => (
        <TouchableOpacity
          key={option}
          style={[
            styles.toggleButton,
            view === option && styles.toggleButtonActive,
          ]}
          onPress={() => setView(option as "day" | "week" | "month")}
        >
          <Text style={{ color: view === option ? "white" : colors.text }}>
            {option.toUpperCase()}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  )

  const renderView = () => {
    switch (view) {
      case "month":
        return (
          <Calendar
            onDayPress={(day: { dateString: string }) => setSelectedDate(day.dateString)}
            markedDates={{ [selectedDate]: { selected: true, selectedColor: colors.palette.primary500 } }}
            theme={{
              selectedDayBackgroundColor: colors.palette.primary500,
              todayTextColor: colors.palette.primary500,
              arrowColor: colors.palette.primary500,
            }}
          />
        )
      case "week":
        return (
          <Text style={styles.message}>Week view coming soon!</Text>
        )
      case "day":
        return (
          <Text style={styles.message}>Day view coming soon!</Text>
        )
    }
  }

  return (
    <Screen preset="scroll" safeAreaEdges={["top", "bottom"]} contentContainerStyle={styles.container}>
      <Text style={styles.heading}>Habit Calendar</Text>
      {renderToggle()}
      {renderView()}
    </Screen>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: spacing.md,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: spacing.lg,
  },
  toggleContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginBottom: spacing.md,
  },
  toggleButton: {
    paddingVertical: spacing.xs,
    paddingHorizontal: spacing.lg,
    backgroundColor: colors.palette.neutral200,
    borderRadius: 8,
  },
  toggleButtonActive: {
    backgroundColor: colors.palette.primary500,
  },
  message: {
    textAlign: "center",
    marginTop: spacing.xl,
    fontSize: 16,
    color: colors.textDim,
  },
})
